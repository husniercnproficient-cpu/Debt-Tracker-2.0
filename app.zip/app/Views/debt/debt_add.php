<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Hutang Baru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #F4F5F7; font-family: 'Segoe UI', sans-serif; }
        .form-container { max-width: 500px; margin: 50px auto; padding: 20px; background: #fff; border-radius: 16px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); }
        h3 { text-align: center; font-weight: 600; margin-bottom: 20px; }
        .btn { font-size: 16px; }
    </style>
</head>
<body>

<div class="container py-4">

    <div class="form-container">
        <h3>Tambah Aplikasi</h3>

        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <form action="/debt/save" method="post">
            <?= csrf_field() ?>

            <!-- Nama Aplikasi -->
<!-- Nama Aplikasi -->
<div class="mb-3">
    <label class="form-label">Nama Aplikasi</label>
    <select name="namaAplikasi" class="form-control" id="namaAplikasiSelect" required>
        <option value="">Pilih atau ketik nama aplikasi baru</option>
        <?php foreach($namaAplikasiList as $nama): ?>
            <option value="<?= esc($nama) ?>"><?= esc($nama) ?></option>
        <?php endforeach; ?>
    </select>
</div>

            <!-- Tenor -->
            <div class="mb-3">
                <label class="form-label">Tenor (Bulan)</label>
                <input type="number" name="tenor" class="form-control"
                       placeholder="Contoh: 12" min="1" required>
            </div>

            <!-- Tanggal Jatuh Tempo Pertama -->
            <div class="mb-3">
                <label class="form-label">Tanggal Jatuh Tempo Pertama</label>
                <input type="date" name="jatuhTempoPertama" class="form-control" required>
            </div>

            <!-- Jumlah Cicilan -->
            <div class="mb-3">
                <label class="form-label">Jumlah Cicilan per Bulan</label>
                <input type="number" name="jumlahCicilan" class="form-control"
                       placeholder="Contoh: 500000" min="0" required>
            </div>

            <div class="d-grid gap-2 mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="/debt/page" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>

</div>


<!-- Tambahkan JS Select2 sebelum </body> -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('#namaAplikasiSelect').select2({
        tags: true, // bisa menambahkan nama baru
        placeholder: "Pilih atau ketik nama aplikasi baru",
        width: '100%'
    });
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
